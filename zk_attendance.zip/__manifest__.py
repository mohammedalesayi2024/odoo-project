{
    'name': 'ZKTeco Attendance Integration',
    'version': '1.0',
    'depends': ['hr_attendance'],
    'data': [
        'data/cron.xml',
    ],
    'installable': True,
}